$(document).ready(function(){
    var $text = $("#text"),
        $submit = $("input[type='submit']"),
        $listComment = $(".list-comments"),
        $loading = $(".loading"),
        _data,
        $totalCom = $(".total-comment");
    var json_obj;
	$.getJSON("comments.json", function (data) {
		json_obj = data; 
		for (var i = 0; i < json_obj.length; i++) {
		    var counter = json_obj[i]; 
            $(".list-comments").append("<div>", counter.comment,"</div>");	   
		}
		$totalCom.text(json_obj.length);
	});
 

    $($submit).click(function(){
		if($text.html() == ""){
		  alert("Please write a comment!");
		  $text.focus();
		} else{	
			$(".list-comments").append("<div>", $text.html(),"</div>");
			//_data = $text.html();	
			$.getJSON("comments.json", function (data) {
				json_obj = data;
				json_obj.push( { "comment" : $text.html() } );
				txt = JSON.stringify(json_obj);
				$.ajax({
					type: 'POST',
					url: 'jsonData.php',
					data: {json: json_obj},
					dataType: 'json'
				});		
			});
		}
    });
});