<?php
if(isset($_POST['json'])) {
    $json = json_encode($_POST['json']);
	$file = 'comments.json';
    $fp = fopen($file, 'w+');
    fwrite($fp, $json);
    fclose($fp);
} else {
    echo "Object Not Received";
}
?>